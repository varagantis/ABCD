
import { AuthUser } from '../types';

const REGISTRY_KEY = 'buildsync_v15_registry';

/**
 * Retrieves the list of users from localStorage.
 * Includes data validation and error handling to protect against corruption.
 * @returns {AuthUser[]} An array of stored users.
 */
const getStoredUsers = (): AuthUser[] => {
  try {
    const data = localStorage.getItem(REGISTRY_KEY);
    const users = data ? JSON.parse(data) : [];
    
    // Ensure that what we parsed is actually an array, protecting against corrupted data.
    if (!Array.isArray(users)) {
      throw new Error('Stored user data is not in the expected array format.');
    }
    return users;
  } catch (error) {
    console.error("Error reading or parsing user registry from localStorage:", error);
    // If there's any error, clear the corrupted key to prevent future failures.
    localStorage.removeItem(REGISTRY_KEY);
    return [];
  }
};

/**
 * Saves an array of users to localStorage.
 * @param {AuthUser[]} users - The array of users to save.
 */
const saveUsers = (users: AuthUser[]): void => {
  try {
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(users));
  } catch (error) {
    console.error("Error writing user registry to localStorage:", error);
  }
};

/**
 * Adds a new user to the registry if the identifier is unique.
 * @param {AuthUser} user - The user object to save.
 */
const saveUser = (user: AuthUser): void => {
  const users = getStoredUsers();
  if (users.some(u => u.identifier === user.identifier)) {
    console.error("Attempted to save a user with a duplicate identifier.");
    return;
  }
  const newUsers = [...users, user];
  saveUsers(newUsers);
};

/**
 * Finds a user by their unique identifier.
 * @param {string} identifier - The user's email or phone number.
 * @returns {AuthUser | undefined} The found user or undefined.
 */
const findUser = (identifier: string): AuthUser | undefined => {
  const users = getStoredUsers();
  return users.find(u => u.identifier === identifier);
};

/**
 * Updates the password for a user identified by their identifier.
 * @param {string} identifier - The identifier of the user to update.
 * @param {string} newPassword - The new password.
 */
const updateUserPassword = (identifier: string, newPassword: string): void => {
  const users = getStoredUsers();
  let userFound = false;
  const updatedUsers = users.map(u => {
    if (u.identifier === identifier) {
      userFound = true;
      return { ...u, password: newPassword };
    }
    return u;
  });

  if (userFound) {
      saveUsers(updatedUsers);
  } else {
      console.error("Attempted to update password for a non-existent user.");
  }
};

export const authService = {
  saveUser,
  findUser,
  updateUserPassword,
};
